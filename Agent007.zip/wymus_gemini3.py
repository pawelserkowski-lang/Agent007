import os

print("--- WYMUSZANIE MODELU GEMINI-3-PRO-PREVIEW ---")

# 1. MANAGER: Zwraca zawsze gemini-3-pro-preview
MANAGER_CONTENT = r'''import google.generativeai as genai
import os

def get_best_model(api_key=None):
    # WYMUSZENIE NA SZTYWNO
    print("[ModelManager] WYMUSZONO: gemini-3-pro-preview")
    return "models/gemini-3-pro-preview"
'''

# 2. AGENT: Ustawia target_model na gemini-3-pro-preview i wyłącza Search
AGENT_CONTENT = r'''import threading
import logging
import os
import re
import importlib
from typing import Dict, Iterable, List, Optional
from kivy.clock import Clock

class Agent:
    def __init__(self, db_manager, app_instance, genai_client=None, image_loader=None):
        self.db = db_manager
        self.app = app_instance
        self.base_prompt = "ROLE: Gemini Code Assist. TASK: High-performance code generation."
        self.cached_model = "gemini-3-pro-preview"
        self._genai = genai_client
        self._pil_image = image_loader
        self._dependencies_ready = genai_client is not None and image_loader is not None
        self._html_block_pattern = re.compile(r"```html(.*?)```", re.DOTALL)

    def _ensure_dependencies(self) -> bool:
        if self._dependencies_ready: return True
        try:
            import google.generativeai as genai
            from PIL import Image as PIL_Image
            self._genai = genai
            self._pil_image = PIL_Image
            self._dependencies_ready = True
            return True
        except ImportError:
            logging.critical("Brak bibliotek!")
            return False

    def discover_best_model(self, api_key: str) -> Optional[str]:
        return "gemini-3-pro-preview"

    def _check_and_save_html(self, text):
        if not self.app.param_auto_save_files: return None
        match = self._html_block_pattern.search(text)
        if not match: return None
        html_content = match.group(1).strip()
        preview_dir = "preview"
        os.makedirs(preview_dir, exist_ok=True)
        file_path = os.path.join(preview_dir, "index.html")
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            return file_path
        except Exception:
            return None

    def send_message(self, session_id, message, file_contents, images, callback_success, callback_error):
        if not self.app.api_key:
            callback_error("Brak klucza API!")
            return

        def _thread_target():
            if not self._ensure_dependencies():
                Clock.schedule_once(lambda dt: callback_error("Brak bibliotek"), 0)
                return

            # --- KONFIGURACJA SZTYWNA ---
            target_model = "gemini-3-pro-preview"
            tools = [] # Search wylaczony (niezbedne dla stabilnosci)
            
            logging.info(f"[ENGINE] Target={target_model} Search=OFF")

            gen_config = {
                "temperature": self.app.param_temperature,
                "max_output_tokens": int(self.app.param_max_tokens),
            }

            full_text = message
            if file_contents:
                full_text += "\n\n[CONTEXT FILES]:\n"
                for fname, fcontent in file_contents.items():
                    full_text += f"--- FILE: {fname} ---\n{fcontent}\n"
            
            image_paths = images or []
            self.db.add_message(session_id, "user", full_text)

            try:
                self._genai.configure(api_key=self.app.api_key)
                model = self._genai.GenerativeModel(
                    model_name=target_model,
                    system_instruction=self.base_prompt,
                    generation_config=gen_config,
                    tools=tools 
                )

                content_parts = [full_text]
                for img_path in image_paths:
                    try:
                        content_parts.append(self._pil_image.open(img_path))
                    except: pass

                history_data = self.db.get_context_messages(session_id, 10)
                chat_history = []
                for msg in history_data[:-1]:
                    role = "user" if msg["role"] == "user" else "model"
                    chat_history.append({"role": role, "parts": [msg["content"]]})

                chat = model.start_chat(history=chat_history)
                response = chat.send_message(content_parts)
                bot_reply = response.text

                preview_file = self._check_and_save_html(bot_reply)
                if preview_file:
                    Clock.schedule_once(lambda dt: self.app.open_web_preview(preview_file), 0)

                self.db.add_message(session_id, "assistant", bot_reply)
                Clock.schedule_once(lambda dt: callback_success(bot_reply), 0)

            except Exception as exc:
                err_msg = str(exc)
                logging.error(f"Gemini Error: {err_msg}")
                Clock.schedule_once(lambda dt: callback_error(f"Błąd API: {err_msg}"), 0)

        threading.Thread(target=_thread_target, daemon=True).start()
'''

# ZAPISYWANIE
try:
    with open(os.path.join("core", "model_manager.py"), "w", encoding="utf-8") as f:
        f.write(MANAGER_CONTENT)
    print("✅ core/model_manager.py - ZAPISANO (gemini-3-pro-preview)")
except Exception as e:
    print(f"❌ Błąd zapisu managera: {e}")

try:
    with open(os.path.join("core", "agent.py"), "w", encoding="utf-8") as f:
        f.write(AGENT_CONTENT)
    print("✅ core/agent.py - ZAPISANO (gemini-3-pro-preview)")
except Exception as e:
    print(f"❌ Błąd zapisu agenta: {e}")

print("\n🎉 GOTOWE! Uruchom teraz: python launcher.py")