import os

print("--- NAPRAWA WYGLĄDU (DYMKI + KOPIOWANIE) ---")

# Poprawiony plik layout.kv
# Zmiany:
# 1. text_size: Ustawione na sztywno na 75% szerokości okna (zapobiega ściskaniu).
# 2. size: self.texture_size (dopasowuje wysokość do tekstu).
# 3. Przycisk kopiowania: Zawsze widoczny i łatwiej dostępny.

NEW_LAYOUT_KV = r'''#:kivy 2.3.0
#:import ChatScreenLogic ui.screens.chat.ChatScreenLogic
#:import NotepadLogic ui.screens.notepad.NotepadLogic
#:import SessionItem ui.widgets.session_item.SessionItem
#:import FileItem ui.widgets.file_item.FileItem
#:import Window kivy.core.window.Window

<FileItem>:
    orientation: 'horizontal'
    size_hint_y: None
    height: "40dp"
    padding: [5, 0, 5, 0]
    spacing: 5
    radius: [10,]
    elevation: 1
    md_bg_color: [0.25, 0.25, 0.25, 0.9] if app.is_dark_mode else [0.95, 0.95, 0.95, 0.9]
    MDCheckbox:
        id: checkbox
        size_hint: None, None
        size: "30dp", "30dp"
        pos_hint: {'center_y': 0.5}
        active: True
    MDIcon:
        icon: root.icon_name
        pos_hint: {'center_y': 0.5}
        theme_text_color: "Secondary"
        font_size: "20sp"
    MDLabel:
        text: root.filename
        font_style: "Caption"
        shorten: True
        pos_hint: {'center_y': 0.5}
        theme_text_color: "Primary"
    MDIconButton:
        icon: "close"
        theme_text_color: "Error"
        user_font_size: "18sp"
        pos_hint: {'center_y': 0.5}
        on_release: root.remove_func(root)

<ChatBubble>:
    orientation: 'horizontal'
    size_hint_y: None
    adaptive_height: True
    padding: [10, 0, 10, 0]
    spacing: 10
    
    # Pusty widget wypychający dymek użytkownika na prawo
    Widget:
        size_hint_x: 1 if root.is_user else 0
        width: 0 if not root.is_user else self.width

    # Ikona bota (lewa strona)
    MDIcon:
        icon: "leaf" if not root.is_user else "account"
        theme_text_color: "Custom"
        text_color: [0.2, 0.6, 0.2, 1] if not root.is_user else [0.4, 0.4, 0.4, 1]
        font_size: "24sp"
        size_hint: None, None
        size: "30dp", "30dp"
        pos_hint: {'top': 1}
        opacity: 1 if not root.is_user else 0
        disabled: True if root.is_user else False
        width: "30dp" if not root.is_user else 0

    # Karta z wiadomością
    MDCard:
        size_hint: None, None
        # Szerokość karty = szerokość tekstu + marginesy na przycisk kopiowania
        width: label.width + 50
        height: label.height + 20
        radius: [18, 18, 0, 18] if root.is_user else [18, 18, 18, 0]
        md_bg_color: app.theme_cls.primary_color if root.is_user else ([0.15, 0.15, 0.15, 0.95] if app.is_dark_mode else [1, 1, 1, 0.95])
        elevation: 2
        
        MDRelativeLayout:
            size_hint: None, None
            width: label.width + 50
            height: label.height + 20
            
            MDLabel:
                id: label
                text: root.text
                theme_text_color: "Custom"
                text_color: [1, 1, 1, 1] if root.is_user else ([0.9, 0.9, 0.9, 1] if app.is_dark_mode else [0, 0, 0, 0.85])
                
                # --- NAPRAWA SZEROKOŚCI ---
                size_hint: None, None
                
                # 1. Maksymalna szerokość zawijania to 75% szerokości okna
                text_size: (Window.width * 0.75, None)
                
                # 2. Rozmiar widgetu dopasowuje się do tekstu
                size: self.texture_size
                
                # Pozycjonowanie z marginesem na przycisk kopiowania
                pos_hint: {"x": 0, "center_y": .5}
                padding: [15, 10]
                markup: True

            # PRZYCISK KOPIOWANIA (Zawsze widoczny)
            MDIconButton:
                icon: "content-copy"
                theme_text_color: "Custom"
                text_color: [1, 1, 1, 0.6] if root.is_user else [0.5, 0.5, 0.5, 0.6]
                user_font_size: "16sp"
                # Umieszczony w prawym górnym rogu dymka
                pos_hint: {"top": 1, "right": 1}
                on_release: root.copy_content()

    # Pusty widget wypychający dymek bota na lewo
    Widget:
        size_hint_x: 1 if not root.is_user else 0
        width: 0 if root.is_user else self.width

<SessionItem>:
    text: root.title
    theme_text_color: "Primary"
    on_release: app.load_session(root.session_id)
    IconLeftWidget:
        icon: "message-text-outline"
    IconRightWidget:
        icon: "trash-can-outline"
        theme_text_color: "Error"
        on_release: app.delete_session(root.session_id)

<RightControlPanel>:
    orientation: "vertical"
    padding: "10dp"
    spacing: "10dp"
    md_bg_color: app.theme_cls.bg_normal
    MDLabel:
        text: "Centrum Sterowania"
        font_style: "H6"
        size_hint_y: None
        height: "40dp"
        halign: "center"
        theme_text_color: "Primary"
    MDCard:
        orientation: "vertical"
        size_hint_y: None
        adaptive_height: True
        radius: [12,]
        elevation: 1
        padding: "10dp"
        spacing: "6dp"
        md_bg_color: app.theme_cls.bg_dark
        MDLabel:
            text: "Szybki podgląd"
            font_style: "Subtitle2"
            theme_text_color: "Secondary"
            padding_x: "2dp"
        MDBoxLayout:
            adaptive_height: True
            spacing: "8dp"
            MDChip:
                icon: "account"
                text: "Sesja: {}".format(app.current_session_title)
                text_color: [1, 1, 1, 0.95] if app.is_dark_mode else [0, 0, 0, 0.9]
                md_bg_color: [0.2,0.2,0.2,0.35] if app.is_dark_mode else [0.93,0.96,1,0.9]
                radius: 12
            MDChip:
                icon: "brain"
                text: app.current_main_model if app.current_main_model else "Brak"
                text_color: [1, 1, 1, 0.95] if app.is_dark_mode else [0, 0, 0, 0.9]
                md_bg_color: [0.2,0.25,0.2,0.35] if app.is_dark_mode else [0.92,1,0.95,0.9]
                radius: 12
        MDBoxLayout:
            adaptive_height: True
            spacing: "8dp"
            MDChip:
                icon: "earth"
                text: "Online" if app.use_google_search else "Offline"
                text_color: [0.9,0.95,0.9,1] if app.use_google_search else ([0.9,0.6,0.6,1] if app.is_dark_mode else [0.6,0.2,0.2,1])
                md_bg_color: [0.18,0.3,0.2,0.6] if app.use_google_search else ([0.3,0.15,0.15,0.55] if app.is_dark_mode else [1,0.92,0.92,0.9])
                radius: 12
            MDChip:
                icon: "white-balance-sunny" if not app.is_dark_mode else "moon-waning-crescent"
                text: "Jasny" if not app.is_dark_mode else "Ciemny"
                text_color: [1, 1, 1, 0.95] if app.is_dark_mode else [0, 0, 0, 0.9]
                md_bg_color: [0.25,0.25,0.3,0.4] if app.is_dark_mode else [0.95,0.95,1,0.9]
                radius: 12
    MDCard:
        orientation: "vertical"
        size_hint_y: None
        adaptive_height: True
        radius: [10,]
        elevation: 1
        padding: "10dp"
        md_bg_color: app.theme_cls.bg_dark
        MDBoxLayout:
            adaptive_height: True
            spacing: "10dp"
            MDIcon:
                icon: "information"
                theme_text_color: "Custom"
                text_color: app.theme_cls.primary_color
                pos_hint: {'center_y': .5}
            MDBoxLayout:
                orientation: "vertical"
                adaptive_height: True
                MDLabel:
                    text: "Sesja: {}".format(app.current_session_title)
                    font_style: "Body2"
                    theme_text_color: "Primary"
                MDLabel:
                    text: "Model: {}".format(app.current_main_model)
                    font_style: "Caption"
                    theme_text_color: "Secondary"
        MDSeparator:
            height: "1dp"
        MDBoxLayout:
            adaptive_height: True
            spacing: "10dp"
            MDIcon:
                icon: "brightness-6"
                theme_text_color: "Custom"
                text_color: app.theme_cls.primary_color
                pos_hint: {'center_y': .5}
            MDLabel:
                text: "Tryb ciemny"
                pos_hint: {'center_y': .5}
                theme_text_color: "Primary"
            MDSwitch:
                active: app.is_dark_mode
                on_active: app.toggle_theme(self.active)
                pos_hint: {'center_y': .5}
    MDSeparator:
    MDScrollView:
        MDBoxLayout:
            orientation: "vertical"
            adaptive_height: True
            spacing: "15dp"
            padding: [0, 10, 0, 20]
            MDCard:
                orientation: "vertical"
                size_hint_y: None
                adaptive_height: True
                radius: [10,]
                elevation: 1
                padding: "10dp"
                spacing: "8dp"
                md_bg_color: app.theme_cls.bg_dark
                MDBoxLayout:
                    adaptive_height: True
                    spacing: "10dp"
                    MDIcon:
                        icon: "key-variant"
                        theme_text_color: "Custom"
                        text_color: app.theme_cls.primary_color
                        pos_hint: {'center_y': .5}
                    MDTextField:
                        hint_text: "Klucz API Google"
                        text: app.api_key
                        password: True
                        mode: "rectangle"
                        on_text: app.update_api_key(self.text)
                        helper_text: "Przechowywany lokalnie, używany do żądań online."
                        helper_text_mode: "on_focus"
                        size_hint_y: None
                        height: "48dp"
                MDSeparator:
                    height: "1dp"
                MDBoxLayout:
                    orientation: "vertical"
                    adaptive_height: True
                    spacing: "2dp"
            MDLabel:
                text: "Model (wykryty)"
                font_style: "Subtitle2"
                theme_text_color: "Secondary"
            MDLabel:
                text: app.current_main_model
                font_style: "Caption"
                theme_text_color: "Primary"
            MDBoxLayout:
                adaptive_height: True
                spacing: "6dp"
                MDIcon:
                    icon: "refresh"
                    theme_text_color: "Custom"
                    text_color: app.theme_cls.primary_color
                    pos_hint: {'center_y': .5}
                MDRaisedButton:
                    text: "Odśwież modele"
                    elevation: 0
                    md_bg_color: app.theme_cls.primary_color
                    on_release: app.refresh_model_discovery()
                MDFlatButton:
                    text: "Nowa Sesja"
                    on_release: app.start_new_chat()
            MDCard:
                orientation: "vertical"
                size_hint_y: None
                adaptive_height: True
                radius: [10,]
                elevation: 1
                padding: "8dp"
                spacing: "6dp"
                md_bg_color: app.theme_cls.bg_dark
                MDLabel:
                    text: "Zasoby i Pliki"
                    font_style: "Subtitle2"
                    theme_text_color: "Secondary"
                    padding_x: "6dp"
                MDBoxLayout:
                    adaptive_height: True
                    spacing: "8dp"
                    MDIcon:
                        icon: "magnify"
                        theme_text_color: "Custom"
                        text_color: app.theme_cls.primary_color
                        pos_hint: {'center_y': .5}
                    MDSwitch:
                        active: app.use_google_search
                        on_active: app.use_google_search = self.active
                        pos_hint: {'center_y': .5}
                    MDLabel:
                        text: "Google Search (Online)"
                        pos_hint: {'center_y': .5}
                        padding_x: "10dp"
                        theme_text_color: "Primary"
                MDBoxLayout:
                    adaptive_height: True
                    spacing: "8dp"
                    MDIcon:
                        icon: "content-save"
                        theme_text_color: "Custom"
                        text_color: app.theme_cls.primary_color
                        pos_hint: {'center_y': .5}
                    MDSwitch:
                        active: app.param_auto_save_files
                        on_active: app.param_auto_save_files = self.active
                        pos_hint: {'center_y': .5}
                    MDLabel:
                        text: "Automatyczny zapis plików"
                        pos_hint: {'center_y': .5}
                        padding_x: "10dp"
                        theme_text_color: "Primary"
                MDBoxLayout:
                    adaptive_height: True
                    spacing: "8dp"
                    MDIcon:
                        icon: "message-alert"
                        theme_text_color: "Custom"
                        text_color: app.theme_cls.primary_color
                        pos_hint: {'center_y': .5}
                    MDSwitch:
                        active: app.param_stackoverflow
                        on_active: app.param_stackoverflow = self.active
                        pos_hint: {'center_y': .5}
                    MDLabel:
                        text: "StackOverflow Mode"
                        pos_hint: {'center_y': .5}
                        padding_x: "10dp"
                        theme_text_color: "Primary"
            MDCard:
                orientation: "vertical"
                size_hint_y: None
                adaptive_height: True
                radius: [10,]
                elevation: 1
                padding: "10dp"
                spacing: "8dp"
                md_bg_color: app.theme_cls.bg_dark
                MDBoxLayout:
                    adaptive_height: True
                    spacing: "10dp"
                    MDIcon:
                        icon: "github"
                        theme_text_color: "Custom"
                        text_color: app.theme_cls.primary_color
                        pos_hint: {'center_y': .5}
                    MDLabel:
                        text: "GitHub Integracja"
                        font_style: "Subtitle2"
                        theme_text_color: "Secondary"
                        pos_hint: {'center_y': .5}
                MDTextField:
                    hint_text: "owner/repo"
                    text: app.github_repo
                    on_text: app.github_repo = self.text
                    mode: "rectangle"
                    helper_text: "Repozytorium źródłowe"
                    helper_text_mode: "on_focus"
                    size_hint_y: None
                    height: "48dp"
                MDTextField:
                    hint_text: "Gałąź (np. main)"
                    text: app.github_branch
                    on_text: app.github_branch = self.text
                    mode: "rectangle"
                    size_hint_y: None
                    height: "48dp"
                MDTextField:
                    hint_text: "Ścieżki plików (rozdziel przecinkiem)"
                    text: app.github_files
                    on_text: app.github_files = self.text
                    mode: "rectangle"
                    multiline: True
                    size_hint_y: None
                    height: "72dp"
                    helper_text: "np. README.md, src/main.py"
                    helper_text_mode: "on_focus"
                MDTextField:
                    hint_text: "Token GitHub (opcjonalnie)"
                    text: app.github_token
                    on_text: app.github_token = self.text
                    password: True
                    mode: "rectangle"
                    size_hint_y: None
                    height: "48dp"
                    helper_text: "Używany przy repo prywatnych"
                    helper_text_mode: "on_focus"
                MDRaisedButton:
                    text: "Pobierz z GitHub"
                    elevation: 0
                    md_bg_color: app.theme_cls.primary_color
                    on_release: app.fetch_github_files()
            MDLabel:
                text: "Parametry Generowania:"
                font_style: "Subtitle2"
                theme_text_color: "Secondary"
            MDBoxLayout:
                adaptive_height: True
                spacing: "8dp"
                MDIcon:
                    icon: "fire"
                    theme_text_color: "Custom"
                    text_color: app.theme_cls.primary_color
                    pos_hint: {'center_y': .5}
                MDLabel:
                    text: "Kreatywność"
                    font_style: "Caption"
                    theme_text_color: "Secondary"
                    pos_hint: {'center_y': .5}
                MDLabel:
                    id: temperature_value
                    text: "{:.1f}".format(app.param_temperature)
                    font_style: "Caption"
                    halign: "right"
                    theme_text_color: "Primary"
            MDSlider:
                min: 0.0
                max: 1.0
                value: app.param_temperature
                on_value:
                    app.param_temperature = self.value
                    temperature_value.text = "{:.1f}".format(self.value)
                hint: True
            MDBoxLayout:
                adaptive_height: True
                spacing: "8dp"
                MDIcon:
                    icon: "format-letter-case"
                    theme_text_color: "Custom"
                    text_color: app.theme_cls.primary_color
                    pos_hint: {'center_y': .5}
                MDLabel:
                    text: "Długość (Tokeny)"
                    font_style: "Caption"
                    theme_text_color: "Secondary"
                    pos_hint: {'center_y': .5}
                MDLabel:
                    id: max_tokens_value
                    text: "{}".format(int(app.param_max_tokens))
                    font_style: "Caption"
                    halign: "right"
                    theme_text_color: "Primary"
            MDSlider:
                min: 1024
                max: 32000
                value: app.param_max_tokens
                on_value:
                    app.param_max_tokens = self.value
                    max_tokens_value.text = "{}".format(int(self.value))
                hint: True
            MDTextField:
                hint_text: "Księga Zaklęć (System Prompt)"
                text: app.param_custom_text
                on_text: app.param_custom_text = self.text
                mode: "rectangle"
                multiline: True
                size_hint_y: None
                height: "80dp"
                helper_text: "Stała instrukcja dla modelu."
                helper_text_mode: "on_focus"
    MDFlatButton:
        text: "Zapisz i Zamknij"
        pos_hint: {"center_x": .5}
        on_release: app.close_right_drawer()

<MainLayout@MDBoxLayout>:
    MDNavigationLayout:
        MDScreenManager:
            MDScreen:
                MDBottomNavigation:
                    panel_color: app.theme_cls.bg_light
                    text_color_active: app.theme_cls.primary_color
                    MDBottomNavigationItem:
                        name: 'screen_chat'
                        text: 'Czat'
                        icon: 'message-text'
                        MDFloatLayout:
                            FitImage:
                                source: "tlo.webp"
                                opacity: 0.1 if app.is_dark_mode else 0.2
                                allow_stretch: True
                                keep_ratio: False
                            MDBoxLayout:
                                orientation: 'vertical'
                                MDBoxLayout:
                                    size_hint_y: None
                                    height: "70dp"
                                    padding: [10, 5]
                                    md_bg_color: [0.15, 0.15, 0.15, 0.9] if app.is_dark_mode else [1, 1, 1, 0.85]
                                    elevation: 1
                                    MDIconButton:
                                        icon: "history"
                                        on_release: nav_drawer_left.set_state("open")
                                        pos_hint: {"center_y": 0.5}
                                    Image:
                                        source: "logo.webp"
                                        size_hint_x: None
                                        width: "60dp"
                                        allow_stretch: True
                                    MDBoxLayout:
                                        orientation: 'vertical'
                                        padding: [10, 0]
                                        MDLabel:
                                            text: "DebugDruid"
                                            font_style: "Subtitle1"
                                            bold: True
                                            theme_text_color: "Custom"
                                            text_color: app.theme_cls.primary_color
                                        MDLabel:
                                            text: f"Online: {'TAK' if app.use_google_search else 'NIE'} | CLI Mode"
                                            font_style: "Caption"
                                            theme_text_color: "Secondary"
                                            font_size: "10sp"
                                            shorten: True
                                    MDIconButton:
                                        icon: "plus-circle-outline"
                                        tooltip_text: "Nowy Czat"
                                        on_release: app.start_new_chat()
                                    MDIconButton:
                                        icon: "tune-vertical"
                                        tooltip_text: "Opcje"
                                        on_release: nav_drawer_right.set_state("open")
                                ChatScreenLogic:
                                    id: chat_screen
                                    size_hint_y: 1
                    MDBottomNavigationItem:
                        name: 'screen_notepad'
                        text: 'Notatnik'
                        icon: 'notebook-edit'
                        NotepadLogic:
                            id: notepad_screen
                    MDBottomNavigationItem:
                        name: 'screen_logs'
                        text: 'System'
                        icon: 'console'
                        MDBoxLayout:
                            orientation: 'vertical'
                            md_bg_color: app.theme_cls.bg_normal
                            MDTopAppBar:
                                title: "Logi Systemowe"
                                elevation: 0
                                right_action_items: [['delete', lambda x: app.clear_logs()]]
                            MDScrollView:
                                MDLabel:
                                    id: logs_label
                                    text: app.logs_text
                                    theme_text_color: "Custom"
                                    text_color: [0, 1, 0, 1] if app.is_dark_mode else [0, 0, 0, 1]
                                    font_name: "RobotoMono-Regular"
                                    size_hint_y: None
                                    height: self.texture_size[1]
                                    padding: [10, 10]
        MDNavigationDrawer:
            id: nav_drawer_left
            anchor: "left"
            radius: (0, 16, 16, 0)
            MDBoxLayout:
                orientation: "vertical"
                padding: "10dp"
                spacing: "10dp"
                md_bg_color: app.theme_cls.bg_light
                MDLabel:
                    text: "Historia Czatów"
                    font_style: "H6"
                    size_hint_y: None
                    height: "40dp"
                    theme_text_color: "Primary"
                MDSeparator:
                MDScrollView:
                    MDList:
                        id: history_list
        MDNavigationDrawer:
            id: nav_drawer_right
            anchor: "right"
            radius: (16, 0, 0, 16)
            width: "320dp"
            RightControlPanel:
                id: right_panel

<ChatScreenLogic@MDBoxLayout>:
    orientation: 'vertical'
    MDScrollView:
        id: scroll_view
        do_scroll_x: False
        do_scroll_y: True
        MDBoxLayout:
            id: chat_list
            orientation: 'vertical'
            adaptive_height: True
            padding: [20, 20]
            spacing: 20
    MDBoxLayout:
        size_hint_y: None
        height: "20dp" if root.is_processing else "0dp"
        opacity: 1 if root.is_processing else 0
        padding: [20, 0]
        spacing: 10
        MDProgressBar:
            id: progress_bar
            type: "indeterminate"
            color: app.theme_cls.primary_color
        MDLabel:
            id: timer_label
            text: "0.00s"
            font_style: "Caption"
            size_hint_x: None
            width: "50dp"
            halign: "right"
            theme_text_color: "Secondary"

    # Panel plików
    MDScrollView:
        size_hint_y: None
        height: "60dp" if len(file_container.children) > 0 else "0dp"
        md_bg_color: [1, 1, 1, 0.1]
        MDBoxLayout:
            id: file_container
            orientation: 'horizontal'
            adaptive_width: True
            padding: [10, 10]
            spacing: 10

    MDBoxLayout:
        size_hint_y: None
        height: "80dp"
        padding: [15, 10, 15, 15]
        spacing: 10
        md_bg_color: app.theme_cls.bg_light
        MDCard:
            radius: [25,]
            md_bg_color: app.theme_cls.bg_normal
            elevation: 0
            MDTextField:
                id: message_input
                hint_text: "Zapytaj Druida (lub wrzuć pliki)..."
                mode: "round"
                size_hint_x: 0.85
                pos_hint: {"center_y": 0.5}
                on_text_validate: root.send_message()
                padding: [15, 15]
        MDIconButton:
            icon: "send-circle"
            theme_text_color: "Custom"
            text_color: app.theme_cls.primary_color
            user_font_size: "40sp"
            pos_hint: {"center_y": 0.5}
            on_release: root.send_message()

<NotepadLogic@MDBoxLayout>:
    orientation: 'vertical'
    md_bg_color: app.theme_cls.bg_light
    MDTopAppBar:
        title: "Notatnik Dewelopera"
        elevation: 0
        right_action_items:
            [
            ['content-save', lambda x: root.save_to_file(), "Zapisz do pliku"],
            ['content-copy', lambda x: root.copy_to_clipboard(), "Kopiuj"],
            ['send', lambda x: root.send_to_chat(), "Wyślij do Czatu"],
            ['delete', lambda x: root.clear_text(), "Wyczyść"]
            ]
    MDBoxLayout:
        padding: [10, 10]
        MDTextField:
            id: notepad_field
            mode: "rectangle"
            multiline: True
            hint_text: "Tu wpisz kod, notatki lub prompt..."
            font_name: "RobotoMono-Regular"
            font_size: "14sp"
            on_text: root.auto_save()
'''

try:
    with open(os.path.join("ui", "layout.kv"), "w", encoding="utf-8") as f:
        f.write(NEW_LAYOUT_KV)
    print("✅ Sukces! Plik layout.kv został zaktualizowany.")
    print("Teraz dymki powinny mieć poprawną szerokość, a przycisk kopiowania będzie widoczny.")
except Exception as e:
    print(f"❌ Błąd zapisu: {e}")