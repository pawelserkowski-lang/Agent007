import google.generativeai as genai
import os

def get_best_model(api_key=None):
    print("[ModelManager] WYMUSZONO: gemini-3-pro-preview")
    return "models/gemini-3-pro-preview"
