
class BaseModel:
    def load(self): pass
    def unload(self): pass
    def infer(self, img): return img
